   /* 
 * File:   main.cpp
 * Author: Nicholas Mwangi
 * Created on April 24, 2015, 11:27  AM
 * Purpose: Calculating whole sale mark ups
 */

//System Libraries

#include <iostream>//I/O standard


using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
void calculateRetail (cost,perce);


//Execution Begins Here!
 
int main(int argc, char**argv) {
    // Declare variables
    
    float whlSale ; //whole sale price
    
    float pctMakup; // percentage mark up
    
    cout<< "Enter the whole sale price: "<<endl;
    cin>>whlSale;
    
    cout << "Enter the mark up percentage : " <<endl;
    cin>>pctMakup;
    
    
    
    
    return 0;
}
