/*
 * *File: welcome.cc
 * Author: Nicholas Mwangi
 * 
 * Created on March 15, 2015, 8:44 PM
 * Purpose: Ocean Levels
 */

//System Libraries

#include <iostream>

using namespace std;

//User Libraries
//Global Constants
//Execution begins here!!

int main(int argc, char**argv) {
    
    
    
    
    float level5,level7,level10;
    
    level5 = 1.5 * 5;
    
    level7 = 1.5 * 7;
    
    level10 = 1.5 * 10;
    
    // calculate the water level in 5 years
    
    cout<< "The water level in 5 years will be at " << level5 << "."<< endl;
    
    cout<< "The water level in 7 years will be at " << level7 << "."<< endl;
    
    cout<< "The water level in 10 years will be at " << level10 << "."<< endl;
    
    
    
    
    
   
    
    
            
            
            
    
    return 0;
}
    

