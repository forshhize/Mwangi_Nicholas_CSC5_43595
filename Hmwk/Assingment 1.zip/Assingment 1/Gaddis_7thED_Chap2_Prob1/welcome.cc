/*
 * File: main.cpp
 * Author: Nicholas Mwangi
 * Purpose: storage of 2 variables and their total
 * 
 * Created on March 9,2015 3:45 PM
 */

//System Libraries

#include <iostream>
using namespace std;

//User Libraries
//Global Constants


int main(int argc, char**argv) {
    //Declare Variables
    //calculate
    
    int number,nmBer,total;
    
    
    
    
    number = 62;
    
    nmBer = 99;
    
    total = number + nmBer;
    
          
    cout<<" The first number stored is "<<number << "."<<endl;
    
    cout<<" The second number stored is "<<nmBer << "."<<endl;
    
    cout<< "Sum of both variables is " << total << "."<< endl;
    
    return 0;
}
