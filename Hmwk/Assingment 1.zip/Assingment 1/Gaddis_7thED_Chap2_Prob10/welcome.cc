/*
 * File:   Welcome.cpp
 * Author: Nicholas Mwangi
 *
 * Created on March 15, 2015, 5:30 PM
 * Purpose: To calculate selling price of a circuit Board at a 40% profit. 
 * 
 */
//System Libraries


#include <iostream>

using namespace std;

//User Libraries

//Global Constants

//Execution begins Here!!

int main(int argc, char**argv) {
    
    float maxGall, maxDist, mpg;
    
    
    maxGall = 12;
    
    maxDist = 350;
    
    mpg = maxDist / maxGall;
    
    cout<< "The number of miles the car gets per gallon is " << mpg << " miles" << endl;
            
            
    
    
    return 0;
}
