/*
 *File: welcome.cc
 * Author: Nicholas Mwangi
 * 
 * Created on March 15, 2015, 8:12 PM
 * Purpose: Annual Pay
 */

//System Libraries

#include <iostream>

using namespace std;

//User Libraries
//Global Constants
//Execution begins here!!

int main(int argc, char**argv) {
    
    
    
    
    unsigned short payAmt,payPrds,annlPay;
    
    payAmt= 1700.0;
    
    payPrds= 26;
    
    annlPay;
    
    annlPay= payAmt * payPrds;
            
            
    
    
    
    //calculate annual pay
    cout<< "The annual pay is $ " << annlPay << "." << endl;
    
   
    
    
            
            
            
    
    return 0;
}
